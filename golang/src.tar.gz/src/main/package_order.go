package main

import (
    "jrpc"
    "jmq"
)

func main() {
    jrpc.HW()
    jmq.Jmp()
}
